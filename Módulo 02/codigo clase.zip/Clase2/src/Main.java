import entidades.Fecha;
import entidades.Persona;

public class Main {
    public static void main(String[] args) {
        /*Persona unaPersona;
        unaPersona= new Persona("Juan", 444444);
        Persona otraPersona=new Persona();
        unaPersona.setNombre("Martha");
        System.out.println("Persona:" + unaPersona);*/
        int antiguedad;
        Fecha f1=new Fecha(10,1,2025);
        Fecha f2=new Fecha(11,3,2026);
        f1.setAnio(2024);
        System.out.println("Año cargado " + f1.getAnio());
        System.out.println("Fecha: " + f1);
        antiguedad=f2.diferenciaAnios(f1);
        System.out.println("Antiguedad: " + antiguedad);

    }
}