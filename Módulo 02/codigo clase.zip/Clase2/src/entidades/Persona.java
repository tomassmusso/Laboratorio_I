package entidades;

public class Persona {
    private String nombre;
    private int dni;

    public Persona(){

    }
    public Persona(String nombre, int dni){
        this.nombre=nombre;
        this.dni=dni;
    }

    public String toString(){
        return "Nombre: " + nombre +"\n" + "Dni: "+dni;
    }
    public void setNombre(String nombre){
        this.nombre=nombre;
    }
    public void setDni(int dni){
        this.dni=dni;
    }
    public String getNombre()
    {
        return nombre;
    }

}
